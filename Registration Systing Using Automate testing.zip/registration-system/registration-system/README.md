# Intelligent Registration System - Frugal Testing Assignment

## Project Overview
A modern, responsive registration system with complete Selenium automation testing.

## Features

### Frontend
- Responsive design with gradient aesthetics
- Real-time form validation
- Dynamic dropdowns (Country → State → City)
- Password strength indicator
- Mobile-friendly interface

### Automation Testing
- 4 comprehensive test scenarios
- Page Object Model design pattern
- Chrome browser automation
- Screenshot capture functionality
- Maven build system

## Test Results
✅ **All 4 tests passed successfully**
- Test 1: Landing Page Verification
- Test 2: Negative Scenario (Missing Last Name)
- Test 3: Positive Scenario (All Valid Data)
- Test 4: Form Logic Validation

## How to Run

### Frontend
1. Open `frontend/index.html` in any browser
2. Test the registration form functionality

### Automation Tests
```bash
cd selenium-tests
mvn clean test